package com.tang.sppconner.manager;

import com.tang.bluelibrary.SppConnector;

public class SimpleSpp extends SppConnector {
}
